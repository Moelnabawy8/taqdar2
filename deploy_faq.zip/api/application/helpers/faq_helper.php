<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * FAQ content — the single source of truth shared by:
 *   - the crawler SEO page  (Seo::faq → views/seo/faq.php + FAQPage JSON-LD)
 *   - the SPA page content  (Api_frontend_model::get_page('faq'))
 * Answers are plain text so they render safely as both HTML and JSON-LD.
 * Edit the Q&A here once and both surfaces stay in sync.
 */

if (!function_exists('mycom_faq_items')) {
    function mycom_faq_items(): array
    {
        return [
            ['q' => 'What is My-Communication Academy?',
             'a' => 'My-Communication Academy is an online learning platform specialising in telecommunications, 5G, fibre optics, networking, IT, and business skills. Courses are taught by industry-expert instructors and designed to make you job-ready.'],
            ['q' => 'Are the courses online and self-paced?',
             'a' => 'Yes. All courses are fully online and self-paced, so you can learn anytime, anywhere, at your own speed. Once enrolled, you can revisit the lessons whenever you need.'],
            ['q' => 'Do I receive a certificate after completing a course?',
             'a' => 'Yes. When you complete a course you receive a certificate of completion from My-Communication Academy that you can share on LinkedIn and add to your CV.'],
            ['q' => 'Do I need prior experience to start?',
             'a' => 'Most courses start from the fundamentals, so beginners are welcome. Each course page lists any prerequisites and the recommended level: beginner, intermediate, or advanced.'],
            ['q' => 'How do I enrol and pay for a course?',
             'a' => 'Browse the course catalogue, open the course you want, and click enrol. You can pay securely online, and once payment is confirmed you get immediate access to the course content.'],
            ['q' => 'How long do I have access to a course?',
             'a' => 'You get lifetime access to the courses you purchase, including any future updates to that course\'s content.'],
            ['q' => 'Can I get a refund?',
             'a' => 'Yes, within the terms of our refund policy. Please review the Refund Policy page for eligibility, time limits, and the steps to request a refund.'],
            ['q' => 'Will these courses help my career?',
             'a' => 'Our courses focus on practical, in-demand skills in telecom, 5G, networking, and IT, with hands-on projects and recognised certifications designed to help you advance or change your career.'],
            ['q' => 'How can I get help or contact support?',
             'a' => 'Visit our Contact Us page to reach the team by email or phone. We are happy to help with enrolment, payments, technical issues, or choosing the right course.'],
        ];
    }
}

if (!function_exists('mycom_faq_html')) {
    /** FAQ rendered as semantic HTML — used as the SPA page content. */
    function mycom_faq_html(): string
    {
        $out = '';
        foreach (mycom_faq_items() as $f) {
            $out .= '<h2>' . htmlspecialchars($f['q'], ENT_QUOTES, 'UTF-8') . '</h2>';
            $out .= '<p>'  . htmlspecialchars($f['a'], ENT_QUOTES, 'UTF-8') . '</p>';
        }
        return $out;
    }
}
