<?php
require APPPATH . '/libraries/TokenHandler.php';
require APPPATH . 'libraries/REST_Controller.php';

/**
 * Payment API Controller
 * 
 * RESTful API for payment processing, invoices, and subscriptions
 * 
 * @package Academy LMS
 * @version 2.0
 */
class Api_payment extends REST_Controller
{
    protected $tokenHandler;
    
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set(get_settings('timezone'));
        $this->load->database();
        $this->load->library('session');
        $this->load->model('crud_model');
        $this->tokenHandler = new TokenHandler();
        
        // CORS Headers
        // M-01 fix: restrict CORS to known origins only (no wildcard)
        $allowed_origins = ['https://my-communication.uk', 'http://localhost:5173', 'http://localhost:3000', 'http://127.0.0.1:5173'];
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        if (in_array($origin, $allowed_origins)) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Access-Control-Allow-Credentials: true');
        }
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        header('Content-Type: application/json');
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            exit(0);
        }
    }

    // ========== PAYMENT METHODS ==========
    
    /**
     * GET /api_payment/methods
     * Get available payment methods
     */
    public function methods_get()
    {
        $methods = [];

        // Check which payment methods are enabled
        // PayPal (stored as JSON in 'paypal' key)
        $paypal = json_decode(get_settings('paypal'), true);
        if (is_array($paypal) && isset($paypal[0]) && $paypal[0]['active'] == '1') {
            $methods[] = [
                'id' => 'paypal',
                'name' => 'PayPal',
                'description' => 'Pay securely with PayPal'
            ];
        }

        // Stripe gateway removed — TAP and PayPal are the only active gateways.

        if (get_settings('razorpay_active') == 1) {
            $methods[] = [
                'id' => 'razorpay',
                'name' => 'Razorpay',
                'icon' => base_url('assets/frontend/default/img/payment/razorpay.png'),
                'description' => 'Pay with UPI, Cards, Wallets',
                'key_id' => get_settings('razorpay_key')
            ];
        }
        
        if (get_settings('paytm_active') == 1) {
            $methods[] = [
                'id' => 'paytm',
                'name' => 'Paytm',
                'icon' => base_url('assets/frontend/default/img/payment/paytm.png'),
                'description' => 'Pay with Paytm Wallet'
            ];
        }
        
        if (get_settings('flutterwave_active') == 1) {
            $methods[] = [
                'id' => 'flutterwave',
                'name' => 'Flutterwave',
                'icon' => base_url('assets/frontend/default/img/payment/flutterwave.png'),
                'description' => 'Pay with cards or bank transfer'
            ];
        }
        
        if (get_settings('paystack_active') == 1) {
            $methods[] = [
                'id' => 'paystack',
                'name' => 'Paystack',
                'icon' => base_url('assets/frontend/default/img/payment/paystack.png'),
                'description' => 'Pay with cards or bank'
            ];
        }

        // Tap Payments
        $tap_gateway = $this->db->get_where('payment_gateways', ['identifier' => 'tap', 'status' => 1])->row_array();
        if ($tap_gateway) {
            $methods[] = [
                'id' => 'tap',
                'name' => 'Tap Payments',
                'description' => 'Pay with cards, Apple Pay, mada, and more'
            ];
        }

        // Offline payment
        if (get_settings('offline_payment') == 1) {
            $methods[] = [
                'id' => 'offline',
                'name' => 'Offline Payment',
                'icon' => base_url('assets/frontend/default/img/payment/offline.png'),
                'description' => 'Pay via bank transfer',
                'instructions' => get_settings('offline_payment_instruction')
            ];
        }
        
        return $this->response([
            'status' => true,
            'data' => $methods
        ], 200);
    }
    
    /**
     * POST /api_payment/initiate
     * Initiate a payment
     */
    public function initiate_post()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $course_id = $this->input->post('course_id');
        $payment_method = $this->input->post('payment_method');
        $coupon_code = $this->input->post('coupon_code');
        
        if (empty($course_id) || empty($payment_method)) {
            return $this->response(['status' => false, 'message' => 'Course ID and payment method are required'], 400);
        }
        
        // Check if course exists
        $course = $this->db->get_where('course', ['id' => $course_id, 'status' => 'active'])->row_array();
        if (!$course) {
            return $this->response(['status' => false, 'message' => 'Course not found'], 404);
        }
        
        // Check if already enrolled
        $already_enrolled = $this->db->get_where('enrol', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id
        ])->row_array();
        
        if ($already_enrolled) {
            return $this->response(['status' => false, 'message' => 'Already enrolled in this course'], 409);
        }
        
        // Calculate price
        $price = $course['is_free_course'] == 1 ? 0 : ($course['discounted_price'] > 0 ? $course['discounted_price'] : $course['price']);
        $discount = 0;
        
        // Apply coupon if provided
        if (!empty($coupon_code)) {
            $coupon_result = $this->apply_coupon($coupon_code, $course_id, $price, $user['user_id']);
            if ($coupon_result['valid']) {
                $discount = $coupon_result['discount'];
                $price = $coupon_result['final_price'];
            }
        }
        
        // If free course or price is 0
        if ($price <= 0) {
            // Enroll directly
            $this->enroll_user($user['user_id'], $course_id, 0, 'free');
            return $this->response([
                'status' => true,
                'message' => 'Enrolled successfully',
                'data' => ['enrolled' => true, 'payment_required' => false]
            ], 200);
        }
        
        // Generate payment token
        $payment_token = bin2hex(random_bytes(16));
        
        // Store pending payment
        $payment_data = [
            'user_id' => $user['user_id'],
            'course_id' => $course_id,
            'amount' => $price,
            'original_amount' => $course['discounted_price'] > 0 ? $course['discounted_price'] : $course['price'],
            'discount' => $discount,
            'coupon_code' => $coupon_code,
            'payment_method' => $payment_method,
            'payment_token' => $payment_token,
            'status' => 'pending',
            'created_at' => time()
        ];
        
        $this->db->insert('pending_payments', $payment_data);
        
        // Generate payment URL or data based on method
        $payment_info = $this->get_payment_info($payment_method, $price, $course, $payment_token);
        
        return $this->response([
            'status' => true,
            'message' => 'Payment initiated',
            'data' => [
                'payment_token' => $payment_token,
                'amount' => $price,
                'currency' => get_settings('system_currency'),
                'course' => [
                    'id' => $course['id'],
                    'title' => $course['title']
                ],
                'payment_method' => $payment_method,
                'payment_info' => $payment_info
            ]
        ], 200);
    }
    
    /**
     * POST /api_payment/verify
     * Verify a payment
     */
    public function verify_post()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $payment_token = $this->input->post('payment_token');
        $transaction_id = $this->input->post('transaction_id');
        $payment_method = $this->input->post('payment_method');
        
        if (empty($payment_token)) {
            return $this->response(['status' => false, 'message' => 'Payment token required'], 400);
        }
        
        // Get pending payment
        $pending = $this->db->get_where('pending_payments', [
            'payment_token' => $payment_token,
            'user_id' => $user['user_id'],
            'status' => 'pending'
        ])->row_array();
        
        if (!$pending) {
            return $this->response(['status' => false, 'message' => 'Payment not found'], 404);
        }
        
        // Verify with payment gateway
        $verified = $this->verify_with_gateway($payment_method ?: $pending['payment_method'], $transaction_id, $pending['amount']);
        
        if (!$verified['success']) {
            return $this->response([
                'status' => false,
                'message' => $verified['message'] ?? 'Payment verification failed'
            ], 400);
        }
        
        // Enroll user
        $this->enroll_user($user['user_id'], $pending['course_id'], $pending['amount'], $payment_method ?: $pending['payment_method'], $transaction_id);
        
        // Update pending payment
        $this->db->where('id', $pending['id'])->update('pending_payments', [
            'status' => 'completed',
            'transaction_id' => $transaction_id,
            'completed_at' => time()
        ]);
        
        return $this->response([
            'status' => true,
            'message' => 'Payment verified and enrolled successfully',
            'data' => [
                'enrolled' => true,
                'course_id' => $pending['course_id']
            ]
        ], 200);
    }
    
    /**
     * GET /api_payment/history
     * Get payment history
     */
    public function history_get()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $page = $this->input->get('page') ?: 1;
        $limit = $this->input->get('limit') ?: 20;
        $offset = ($page - 1) * $limit;
        
        $this->db->select('p.*, c.title as course_title, c.thumbnail');
        $this->db->from('payment p');
        $this->db->join('course c', 'c.id = p.course_id', 'left');
        $this->db->where('p.user_id', $user['user_id']);
        
        $total = $this->db->count_all_results('', false);
        
        $payments = $this->db->order_by('p.date_added', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->result_array();
        
        foreach ($payments as &$payment) {
            $payment['date_formatted'] = date('Y-m-d H:i', $payment['date_added']);
            $payment['thumbnail_url'] = $this->get_course_thumbnail($payment['course_id']);
        }
        
        return $this->response([
            'status' => true,
            'data' => $payments,
            'pagination' => [
                'total' => $total,
                'page' => (int)$page,
                'limit' => (int)$limit,
                'total_pages' => ceil($total / $limit)
            ]
        ], 200);
    }
    
    /**
     * GET /api_payment/invoice/{payment_id}
     * Get payment invoice
     */
    public function invoice_get($payment_id = null)
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        if (!$payment_id) {
            return $this->response(['status' => false, 'message' => 'Payment ID required'], 400);
        }
        
        $payment = $this->db->select('p.*, c.title as course_title, c.thumbnail, u.first_name, u.last_name, u.email')
            ->from('payment p')
            ->join('course c', 'c.id = p.course_id', 'left')
            ->join('users u', 'u.id = p.user_id', 'left')
            ->where('p.id', $payment_id)
            ->where('p.user_id', $user['user_id'])
            ->get()
            ->row_array();
        
        if (!$payment) {
            return $this->response(['status' => false, 'message' => 'Invoice not found'], 404);
        }
        
        $invoice = [
            'invoice_number' => 'INV-' . str_pad($payment['id'], 8, '0', STR_PAD_LEFT),
            'date' => date('Y-m-d', $payment['date_added']),
            'customer' => [
                'name' => $payment['first_name'] . ' ' . $payment['last_name'],
                'email' => $payment['email']
            ],
            'items' => [
                [
                    'name' => $payment['course_title'],
                    'quantity' => 1,
                    'price' => $payment['amount']
                ]
            ],
            'subtotal' => $payment['amount'],
            'tax' => 0,
            'total' => $payment['amount'],
            'currency' => get_settings('system_currency'),
            'payment_method' => $payment['payment_type'] ?? 'Online',
            'transaction_id' => $payment['transaction_id'] ?? null,
            'company' => [
                'name' => get_settings('system_name'),
                'email' => get_settings('system_email'),
                'address' => get_settings('address')
            ]
        ];
        
        return $this->response(['status' => true, 'data' => $invoice], 200);
    }
    
    /**
     * POST /api_payment/apply_coupon
     * Apply coupon code
     */
    public function apply_coupon_post()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $coupon_code = $this->input->post('coupon_code');
        $course_id = $this->input->post('course_id');
        
        if (empty($coupon_code) || empty($course_id)) {
            return $this->response(['status' => false, 'message' => 'Coupon code and course ID required'], 400);
        }
        
        $course = $this->db->get_where('course', ['id' => $course_id])->row_array();
        if (!$course) {
            return $this->response(['status' => false, 'message' => 'Course not found'], 404);
        }
        
        $price = $course['discounted_price'] > 0 ? $course['discounted_price'] : $course['price'];
        $result = $this->apply_coupon($coupon_code, $course_id, $price);
        
        if (!$result['valid']) {
            return $this->response(['status' => false, 'message' => $result['message']], 400);
        }
        
        return $this->response([
            'status' => true,
            'message' => 'Coupon applied successfully',
            'data' => [
                'original_price' => $price,
                'discount' => $result['discount'],
                'discount_percentage' => $result['percentage'],
                'final_price' => $result['final_price']
            ]
        ], 200);
    }
    
    /**
     * POST /api_payment/offline
     * Submit offline payment
     */
    public function offline_post()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $course_id = $this->input->post('course_id');
        $document = $_FILES['document'] ?? null;
        
        if (empty($course_id)) {
            return $this->response(['status' => false, 'message' => 'Course ID required'], 400);
        }
        
        // Check course
        $course = $this->db->get_where('course', ['id' => $course_id, 'status' => 'active'])->row_array();
        if (!$course) {
            return $this->response(['status' => false, 'message' => 'Course not found'], 404);
        }
        
        // Check if already enrolled
        $already = $this->db->get_where('enrol', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id
        ])->row_array();
        
        if ($already) {
            return $this->response(['status' => false, 'message' => 'Already enrolled'], 409);
        }
        
        $price = $course['discounted_price'] > 0 ? $course['discounted_price'] : $course['price'];
        
        // Handle document upload if provided (C-02 fix: strict allowlist + MIME check + random name)
        $document_path = null;
        if ($document && $document['error'] == 0) {
            // 1. Size limit: 5 MB
            $max_size = 5 * 1024 * 1024;
            if ($document['size'] > $max_size) {
                return $this->response(['status' => false, 'message' => 'File too large. Maximum 5 MB allowed.'], 400);
            }

            // 2. Extension allowlist (only images + PDF — no PHP, no script files)
            $ext = strtolower(pathinfo($document['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg', 'jpeg', 'png', 'pdf'];
            if (!in_array($ext, $allowed_ext, true)) {
                return $this->response(['status' => false, 'message' => 'Invalid file type. Only JPG, PNG, and PDF are allowed.'], 400);
            }

            // 3. MIME type verification using finfo (belt-and-suspenders)
            $allowed_mime = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($document['tmp_name']);
            if (!in_array($mime, $allowed_mime, true)) {
                return $this->response(['status' => false, 'message' => 'File content does not match the allowed types.'], 400);
            }

            // 4. Random filename — never trust the original name
            $upload_dir = FCPATH . 'uploads/offline_payments/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0750, true);
            }
            $random_name = bin2hex(random_bytes(16)) . '.' . $ext;
            if (move_uploaded_file($document['tmp_name'], $upload_dir . $random_name)) {
                $document_path = 'uploads/offline_payments/' . $random_name;
            }
        }
        
        // Create pending enrollment
        $this->db->insert('pending_enrol', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id,
            'amount' => $price,
            'payment_type' => 'offline',
            'document' => $document_path,
            'status' => 'pending',
            'created_at' => time()
        ]);
        
        return $this->response([
            'status' => true,
            'message' => 'Offline payment submitted. Awaiting admin approval.',
            'data' => [
                'pending_id' => $this->db->insert_id()
            ]
        ], 201);
    }

    // ========== CART OPERATIONS ==========
    
    /**
     * GET /api_payment/cart
     * Get cart items
     */
    public function cart_get()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $cart_items = $this->db->select('c.*, cr.title, cr.price, cr.discounted_price, cr.discount_flag, cr.is_free_course, cr.thumbnail, cr.user_id as instructor_id')
            ->from('cart c')
            ->join('course cr', 'cr.id = c.course_id')
            ->where('c.user_id', $user['user_id'])
            ->get()
            ->result_array();

        $total = 0;
        foreach ($cart_items as &$item) {
            // Match the price the checkout actually charges: a discount only
            // applies when discount_flag is on AND a discounted price exists.
            $item['effective_price'] = $item['is_free_course'] == 1 ? 0 :
                (($item['discount_flag'] == 1 && $item['discounted_price'] > 0) ? $item['discounted_price'] : $item['price']);
            $item['thumbnail_url'] = $this->get_course_thumbnail($item['course_id']);
            // The raw cr.thumbnail column is just a filename; the frontend reads
            // `thumbnail` first, so overwrite it with the resolved public path.
            $item['thumbnail'] = $item['thumbnail_url'];
            $item['instructor'] = $this->get_instructor_info($item['instructor_id']);
            $total += $item['effective_price'];
        }
        
        return $this->response([
            'status' => true,
            'data' => [
                'items' => $cart_items,
                'subtotal' => $total,
                'currency' => get_settings('system_currency')
            ]
        ], 200);
    }
    
    /**
     * POST /api_payment/cart/add
     * Add item to cart
     */
    public function cart_add_post()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $course_id = $this->input->post('course_id');
        
        if (empty($course_id)) {
            return $this->response(['status' => false, 'message' => 'Course ID required'], 400);
        }
        
        // Check course exists
        $course = $this->db->get_where('course', ['id' => $course_id, 'status' => 'active'])->row_array();
        if (!$course) {
            return $this->response(['status' => false, 'message' => 'Course not found'], 404);
        }
        
        // Check if already enrolled
        $enrolled = $this->db->get_where('enrol', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id
        ])->row_array();
        
        if ($enrolled) {
            return $this->response(['status' => false, 'message' => 'Already enrolled in this course'], 409);
        }
        
        // Check if already in cart
        $in_cart = $this->db->get_where('cart', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id
        ])->row_array();
        
        if ($in_cart) {
            return $this->response(['status' => false, 'message' => 'Course already in cart'], 409);
        }
        
        // Add to cart
        $this->db->insert('cart', [
            'user_id' => $user['user_id'],
            'course_id' => $course_id,
            'date_added' => time()
        ]);
        
        return $this->response([
            'status' => true,
            'message' => 'Added to cart',
            'data' => ['cart_id' => $this->db->insert_id()]
        ], 201);
    }
    
    /**
     * DELETE /api_payment/cart/remove/{course_id}
     * Remove item from cart
     */
    public function cart_remove_delete($course_id = null)
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        if (!$course_id) {
            return $this->response(['status' => false, 'message' => 'Course ID required'], 400);
        }
        
        $this->db->where('user_id', $user['user_id'])
            ->where('course_id', $course_id)
            ->delete('cart');
        
        return $this->response(['status' => true, 'message' => 'Removed from cart'], 200);
    }
    
    /**
     * DELETE /api_payment/cart/clear
     * Clear entire cart
     */
    public function cart_clear_delete()
    {
        $user = $this->authenticate();
        if (!$user) return;
        
        $this->db->where('user_id', $user['user_id'])->delete('cart');
        
        return $this->response(['status' => true, 'message' => 'Cart cleared'], 200);
    }
    
    /**
     * POST /api_payment/checkout
     * Checkout entire cart — creates a TAP charge or PayPal order
     * (payment_method is mandatory: 'tap' or 'paypal').
     */
    public function checkout_post()
    {
        $user = $this->authenticate();
        if (!$user) return;

        // Payment method is mandatory and must be one of the active gateways
        // (TAP = "Debit or credit cards", PayPal). Stripe is no longer supported.
        $payment_method = $this->input->post('payment_method');
        if (!in_array($payment_method, ['tap', 'paypal'], true)) {
            return $this->response(['status' => false, 'message' => 'Please choose a payment method before checking out.'], 400);
        }

        // Get cart from the `cart` table — the same store the cart page and
        // add-to-cart use (users.cart_items is a dead legacy store).
        $cart_rows = $this->db->select('course_id')->get_where('cart', ['user_id' => $user['user_id']])->result_array();
        $cart_ids = array_map(function ($r) { return (int)$r['course_id']; }, $cart_rows);

        if (empty($cart_ids)) {
            return $this->response(['status' => false, 'message' => 'Cart is empty'], 400);
        }

        // Calculate total
        $total = 0;
        $course_ids = [];
        $line_items = [];
        foreach ($cart_ids as $cid) {
            $course = $this->db->get_where('course', ['id' => $cid])->row_array();
            if (!$course) continue;
            $course_ids[] = $cid;
            if ($course['is_free_course'] != 1) {
                $price = ($course['discount_flag'] == 1 && $course['discounted_price'] > 0) ? (float)$course['discounted_price'] : (float)$course['price'];
                $total += $price;
                $line_items[] = ['name' => $course['title'], 'price' => $price];
            }
        }

        if ($total == 0) {
            // All free — enroll directly
            foreach ($course_ids as $cid) {
                $this->enroll_user($user['user_id'], $cid, 0, 'free');
            }
            $this->db->where('user_id', $user['user_id'])->delete('cart');
            return $this->response(['status' => true, 'message' => 'Enrolled in all courses', 'data' => ['enrolled' => true]], 200);
        }

        // Store pending checkout
        $checkout_token = bin2hex(random_bytes(16));

        // Stripe checkout removed — only PayPal and TAP are supported below.

        // Handle PayPal checkout
        if ($payment_method == 'paypal') {
            $paypal = json_decode(get_settings('paypal'), true);
            if (!$paypal || !isset($paypal[0])) {
                return $this->response(['status' => false, 'message' => 'PayPal not configured'], 500);
            }
            $is_sandbox = ($paypal[0]['mode'] ?? 'sandbox') == 'sandbox';
            $client_id = $is_sandbox ? $paypal[0]['sandbox_client_id'] : $paypal[0]['production_client_id'];
            $secret = $is_sandbox ? $paypal[0]['sandbox_secret_key'] : $paypal[0]['production_secret_key'];
            $api_url = $is_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

            // Get access token
            $ch = curl_init($api_url . '/v1/oauth2/token');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
                CURLOPT_USERPWD => $client_id . ':' . $secret,
            ]);
            $token_result = json_decode(curl_exec($ch), true);
            curl_close($ch);

            if (!isset($token_result['access_token'])) {
                return $this->response(['status' => false, 'message' => 'PayPal authentication failed'], 500);
            }

            $currency = strtoupper(get_settings('paypal_currency') ?: 'USD');

            // Create PayPal order
            $order_data = json_encode([
                'intent' => 'CAPTURE',
                'purchase_units' => [[
                    'amount' => ['currency_code' => $currency, 'value' => number_format($total, 2, '.', '')],
                    'description' => 'Course purchase - ' . count($course_ids) . ' course(s)',
                ]],
                'application_context' => [
                    'return_url' => site_url('api_frontend/payment_success?token=' . $checkout_token),
                    'cancel_url' => site_url('api_frontend/payment_cancel?token=' . $checkout_token),
                ],
            ]);

            $ch = curl_init($api_url . '/v2/checkout/orders');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $order_data,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $token_result['access_token'],
                ],
            ]);
            $order_result = json_decode(curl_exec($ch), true);
            curl_close($ch);

            $approve_link = null;
            if (isset($order_result['links'])) {
                foreach ($order_result['links'] as $link) {
                    if ($link['rel'] == 'approve') {
                        $approve_link = $link['href'];
                        break;
                    }
                }
            }

            if (!$approve_link) {
                return $this->response(['status' => false, 'message' => 'Failed to create PayPal order', 'error' => $order_result], 500);
            }

            // Save PENDING payment record with the purchased-courses snapshot.
            $this->db->insert('payment', [
                'user_id' => $user['user_id'],
                'payment_type' => 'paypal',
                'course_id' => $course_ids[0],
                'course_ids' => json_encode($course_ids),
                'status' => 'pending',
                'amount' => $total,
                'transaction_id' => $order_result['id'] ?? '',
                'session_id' => $checkout_token,
                'date_added' => time(),
            ]);

            return $this->response([
                'status' => true,
                'data' => [
                    'redirect_url' => $approve_link,
                    'checkout_token' => $checkout_token,
                    'total' => $total,
                ]
            ], 200);
        }

        // Handle Tap checkout
        if ($payment_method == 'tap') {
            $tap_gateway = $this->db->get_where('payment_gateways', ['identifier' => 'tap', 'status' => 1])->row_array();
            if (!$tap_gateway) {
                return $this->response(['status' => false, 'message' => 'Tap Payments not configured'], 500);
            }

            $keys = json_decode($tap_gateway['keys'], true);
            $api_key = ($tap_gateway['enabled_test_mode'] == 1) ? $keys['test_secret_key'] : $keys['live_secret_key'];
            $currency = $tap_gateway['currency'] ?: 'USD';

            $user_details = $this->db->get_where('users', ['id' => $user['user_id']])->row_array();

            $course_names = array_map(function($item) { return $item['name']; }, $line_items);
            $description = 'Purchase: ' . implode(', ', array_slice($course_names, 0, 3));
            if (count($course_names) > 3) {
                $description .= ' +' . (count($course_names) - 3) . ' more';
            }

            $charge_data = [
                'amount' => $total,
                'currency' => $currency,
                'threeDSecure' => true,
                'save_card' => false,
                'description' => $description,
                'metadata' => [
                    'udf1' => 'cart_checkout',
                    'udf2' => (string)$user['user_id'],
                    'udf3' => $checkout_token
                ],
                'reference' => [
                    'transaction' => 'txn_' . time(),
                    'order' => 'ord_' . $checkout_token
                ],
                'receipt' => [
                    'email' => true,
                    'sms' => false
                ],
                'customer' => [
                    'first_name' => $user_details['first_name'] ?: 'Customer',
                    'last_name' => $user_details['last_name'] ?: '',
                    'email' => $user_details['email'],
                    'phone' => [
                        'country_code' => '20',
                        'number' => $user_details['phone'] ?: ''
                    ]
                ],
                'source' => [
                    'id' => 'src_all'
                ],
                'redirect' => [
                    'url' => site_url('api_frontend/tap_success?token=' . $checkout_token)
                ],
                'post' => [
                    'url' => site_url('payment/tap_webhook')
                ]
            ];

            $ch = curl_init('https://api.tap.company/v2/charges');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($charge_data),
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $api_key,
                    'Content-Type: application/json',
                    'Accept: application/json'
                ],
                CURLOPT_TIMEOUT => 30,
            ]);
            $result = json_decode(curl_exec($ch), true);
            $curl_err = curl_error($ch);
            curl_close($ch);

            if ($curl_err || !isset($result['id'])) {
                log_message('error', 'Tap charge creation failed: ' . ($curl_err ?: json_encode($result)));
                return $this->response([
                    'status' => false,
                    'message' => 'Failed to create Tap payment',
                    'error' => isset($result['errors']) ? $result['errors'] : $curl_err
                ], 500);
            }

            $redirect_url = isset($result['transaction']['url']) ? $result['transaction']['url'] : null;
            if (!$redirect_url) {
                return $this->response(['status' => false, 'message' => 'No redirect URL from Tap'], 500);
            }

            $this->db->insert('payment', [
                'user_id' => $user['user_id'],
                'payment_type' => 'tap',
                'course_id' => $course_ids[0],
                'course_ids' => json_encode($course_ids),
                'status' => 'pending',
                'amount' => $total,
                'transaction_id' => $result['id'],
                'session_id' => $checkout_token,
                'date_added' => time(),
            ]);

            return $this->response([
                'status' => true,
                'data' => [
                    'redirect_url' => $redirect_url,
                    'checkout_token' => $checkout_token,
                    'total' => $total,
                ]
            ], 200);
        }

        // Fail closed: a paid cart must go through a gateway above. Reaching here
        // means the gateway produced no redirect — never report success (which
        // would falsely enroll/redirect the user without a real payment).
        return $this->response([
            'status'  => false,
            'message' => 'Could not start the payment. Please try again or contact support.'
        ], 502);
    }

    // ========== HELPER METHODS ==========
    
    private function apply_coupon($code, $course_id, $price, $user_id)
    {
        $coupon = $this->db->get_where('coupon', [
            'code' => $code,
            'status' => 1
        ])->row_array();
        
        if (!$coupon) {
            return ['valid' => false, 'message' => 'Invalid coupon code'];
        }
        
        // Check expiry
        if ($coupon['expiry_date'] && strtotime($coupon['expiry_date']) < time()) {
            return ['valid' => false, 'message' => 'Coupon has expired'];
        }
        
        // Check course restriction
        if (!empty($coupon['course_id']) && $coupon['course_id'] != $course_id) {
            return ['valid' => false, 'message' => 'Coupon not valid for this course'];
        }
        
        // Check usage limit globally
        if ($coupon['limit'] > 0) {
            $used = $this->db->where('coupon_code', $code)->count_all_results('payment');
            if ($used >= $coupon['limit']) {
                return ['valid' => false, 'message' => 'Coupon usage limit reached'];
            }
        }

        // M-04 fix: Check per-user usage limit (atomic)
        $user_usage = $this->db->where('coupon_code', $code)->where('user_id', $user_id)->count_all_results('payment');
        if ($user_usage > 0) {
            return ['valid' => false, 'message' => 'You have already used this coupon'];
        }
        
        // M-04 fix: Calculate discount and cap it at 100%
        $percentage = min(100, max(0, (float)$coupon['discount']));
        $discount = ($price * $percentage) / 100;
        $final = max(0, $price - $discount);
        
        return [
            'valid' => true,
            'discount' => $discount,
            'percentage' => $percentage,
            'final_price' => $final
        ];
    }
    
    private function enroll_user($user_id, $course_id, $amount, $payment_type, $transaction_id = null)
    {
        $course = $this->db->get_where('course', ['id' => $course_id])->row_array();
        if (!$course) return;

        // Idempotent enrollment — never create a duplicate enrol row.
        $already = $this->db->get_where('enrol', ['user_id' => $user_id, 'course_id' => $course_id])->num_rows() > 0;
        if (!$already) {
            // Limited-time courses must carry an expiry; empty = lifetime.
            $expiry = null;
            if ((int) ($course['expiry_period'] ?? 0) > 0) {
                $expiry = strtotime('+' . (int) $course['expiry_period'] . ' months');
            }
            $this->db->insert('enrol', [
                'user_id' => $user_id,
                'course_id' => $course_id,
                'date_added' => time(),
                'expiry_date' => $expiry,
            ]);
        }

        // One accounting row per paid course, with the instructor's own rate.
        if ($amount > 0) {
            $instructor_revenue = $this->calculate_instructor_revenue($amount, $course['user_id']);
            $this->db->insert('payment', [
                'user_id' => $user_id,
                'course_id' => $course_id,
                'amount' => $amount,
                'instructor_revenue' => $instructor_revenue,
                'admin_revenue' => $amount - $instructor_revenue,
                'payment_type' => $payment_type,
                'transaction_id' => $transaction_id,
                'status' => 'completed',
                'date_added' => time(),
            ]);
        }
    }
    
    private function calculate_instructor_revenue($amount, $instructor_id)
    {
        $instructor = $this->db->get_where('users', ['id' => $instructor_id])->row_array();
        $instructor_percentage = $instructor['instructor_revenue_percentage'] ?? get_settings('instructor_revenue') ?? 70;
        return ($amount * $instructor_percentage) / 100;
    }
    
    private function get_payment_info($method, $amount, $course, $token)
    {
        $currency = get_settings('system_currency');
        
        switch ($method) {
            case 'razorpay':
                return [
                    'key_id' => get_settings('razorpay_key'),
                    'amount' => $amount * 100,
                    'currency' => $currency,
                    'name' => get_settings('system_name'),
                    'description' => $course['title']
                ];
            
            case 'paypal':
                return [
                    'client_id' => get_settings('paypal') == 'sandbox' ? 
                        get_settings('paypal_sandbox_client_id') : 
                        get_settings('paypal_live_client_id'),
                    'amount' => $amount,
                    'currency' => $currency
                ];
                
            default:
                return ['amount' => $amount, 'currency' => $currency];
        }
    }
    
    private function verify_with_gateway($method, $transaction_id, $amount)
    {
        // Fail closed: never grant access without a real, captured charge of
        // the expected amount. An empty/unknown gateway is a hard failure.
        if (empty($transaction_id)) {
            return ['success' => false, 'message' => 'No transaction ID provided'];
        }
        try {
            if ($method === 'paypal') {
                $paypal = json_decode(get_settings('paypal'), true);
                if (!$paypal || !isset($paypal[0])) return ['success' => false, 'message' => 'PayPal not configured'];
                $is_sandbox = ($paypal[0]['mode'] ?? 'sandbox') == 'sandbox';
                $client_id = $is_sandbox ? $paypal[0]['sandbox_client_id'] : $paypal[0]['production_client_id'];
                $secret = $is_sandbox ? $paypal[0]['sandbox_secret_key'] : $paypal[0]['production_secret_key'];
                $base = $is_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

                $tok = curl_init($base . '/v1/oauth2/token');
                curl_setopt_array($tok, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
                    CURLOPT_USERPWD => $client_id . ':' . $secret,
                    CURLOPT_POSTFIELDS => 'grant_type=client_credentials']);
                $tok_res = json_decode(curl_exec($tok), true);
                curl_close($tok);
                $access = $tok_res['access_token'] ?? null;
                if (!$access) return ['success' => false, 'message' => 'PayPal auth failed'];

                $ch = curl_init($base . '/v2/checkout/orders/' . urlencode($transaction_id));
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $access]]);
                $order = json_decode(curl_exec($ch), true);
                curl_close($ch);
                if (!$order || ($order['status'] ?? '') !== 'COMPLETED') return ['success' => false, 'message' => 'Payment not completed'];
                $paid_amt = (float) ($order['purchase_units'][0]['amount']['value'] ?? 0);
                if ($paid_amt + 0.01 < (float) $amount) return ['success' => false, 'message' => 'Amount mismatch'];
                return ['success' => true];
            }
        } catch (\Exception $e) {
            return ['success' => false, 'message' => 'Verification error'];
        }
        return ['success' => false, 'message' => 'Unsupported payment method'];
    }
    
    private function get_course_thumbnail($course_id)
    {
        // Mirror the resolver used elsewhere (theme + last_modified naming with
        // optimized/webp fallbacks) so the cart shows the real thumbnail.
        $course = $this->db->select('last_modified')->get_where('course', ['id' => $course_id])->row_array();
        if (!$course) return null;
        $theme = function_exists('get_frontend_settings') ? (get_frontend_settings('theme') ?: 'default-new') : 'default-new';
        $base = 'course_thumbnail_' . $theme . '_' . $course_id . ($course['last_modified'] ?? '');
        $opt = 'uploads/thumbnails/course_thumbnails/optimized/';
        $orig = 'uploads/thumbnails/course_thumbnails/';
        if (file_exists(FCPATH . $opt . $base . '.webp')) return '/' . $opt . $base . '.webp';
        if (file_exists(FCPATH . $opt . $base . '.jpg')) return '/' . $opt . $base . '.jpg';
        if (file_exists(FCPATH . $orig . $base . '.jpg')) return '/' . $orig . $base . '.jpg';
        return base_url() . $opt . $base . '.jpg';
    }
    
    private function get_instructor_info($instructor_id)
    {
        $instructor = $this->db->select('id, first_name, last_name')
            ->get_where('users', ['id' => $instructor_id])
            ->row_array();
        
        if ($instructor) {
            return [
                'id' => $instructor['id'],
                'name' => $instructor['first_name'] . ' ' . $instructor['last_name']
            ];
        }
        return null;
    }
    
    private function authenticate()
    {
        $auth_token = $this->input->get('auth_token') ?: $this->input->post('auth_token');
        if (!$auth_token) {
            $headers = $this->input->request_headers();
            $auth_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;
        }
        
        if (!$auth_token) {
            $this->response(['status' => false, 'message' => 'Authentication required'], 401);
            return false;
        }
        
        try {
            $decoded = $this->tokenHandler->DecodeToken($auth_token);
            return $decoded;
        } catch (Exception $e) {
            $this->response(['status' => false, 'message' => 'Invalid or expired token'], 401);
            return false;
        }
    }
}
