<?php
require APPPATH . '/libraries/JWT.php';

class TokenHandler
{
    /**
     * Signing secret. Loaded from the JWT_SECRET environment variable when
     * available; otherwise a per-install random secret (rotated away from the
     * public Academy-LMS template default, which was forgeable by anyone).
     * Rotating this value invalidates existing sessions (users re-login).
     */
    private $key;

    /** Token lifetime in seconds (30 days). */
    private $ttl = 2592000;

    public function __construct()
    {
        $env = getenv('JWT_SECRET');
        if (!$env || strlen($env) < 32) {
            throw new RuntimeException("CRITICAL: JWT_SECRET environment variable is missing or too short. It must be at least 32 characters long for security. Set it in the server environment (e.g., Apache SetEnv, Nginx fastcgi_param, or Docker env).");
        }
        $this->key = $env;
    }

    //////////The function generate token/////////////
    public function GenerateToken($data)
    {
        $data = (array) $data;
        $now = time();
        // Stamp issued-at / expiry so tokens are not valid forever.
        $data['iat'] = $now;
        $data['exp'] = $now + $this->ttl;
        return JWT::encode($data, $this->key);
    }

    //////This function decode the token////////////////////
    // JWT::decode auto-validates exp/nbf/iat and throws on expiry,
    // so callers' existing try/catch will treat expired tokens as guests.
    public function DecodeToken($token)
    {
        $decoded = JWT::decode($token, $this->key, array('HS256'));
        $decodedData = (array) $decoded;
        return $decodedData;
    }
}
