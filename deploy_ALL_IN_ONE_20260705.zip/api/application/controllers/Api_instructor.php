<?php
require APPPATH . '/libraries/TokenHandler.php';
//include Rest Controller library
require APPPATH . 'libraries/REST_Controller.php';

class Api_instructor extends REST_Controller {

  protected $token;
  public function __construct()
  {
    parent::__construct();

    date_default_timezone_set(get_settings('timezone'));
    
    $this->load->database();
    $this->load->library('session');
    $this->load->model('api_instructor_model');
    // creating object of TokenHandler class at first
    $this->tokenHandler = new TokenHandler();
    header('Content-Type: application/json');

  }
  public function token_data_get($auth_token)
  {
    if (isset($auth_token)) {
      try
      {
        $jwtData = $this->tokenHandler->DecodeToken($auth_token);
        // M-02 fix: Enforce role check — only instructors can access Api_instructor
        if (!isset($jwtData['is_instructor']) || $jwtData['is_instructor'] != 1) {
            throw new Exception("Access denied: Instructor privileges required.");
        }
        return json_encode($jwtData);
      }
      catch (Exception $e)
      {
        http_response_code('403'); // Changed to 403 Forbidden for auth/role errors
        echo json_encode(array( "status" => false, "message" => $e->getMessage()));
        exit;
      }
    }else{
      echo json_encode(array( "status" => false, "message" => "Invalid Token"));
      exit;
    }
  }

  public function login_post() {
    $userdata = $this->api_instructor_model->login_post();
    if ($userdata['validity'] == 1) {      
      $userdata['token'] = $this->tokenHandler->GenerateToken($userdata);
    }
    return $this->set_response($userdata, REST_Controller::HTTP_OK);
  }

  public function change_password_post(){
    $response = array();
    if (isset($_POST['auth_token']) && !empty($_POST['auth_token']) && !empty($_POST['current_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
      $auth_token = $_POST['auth_token'];
      $logged_in_user_details = json_decode($this->token_data_get($auth_token), true);
      if ($logged_in_user_details['user_id'] > 0) {
        $response = $this->api_instructor_model->change_password_post($logged_in_user_details['user_id']);
      }
    }else{
      $response['message'] = 'Access denied';
      $response['status'] = 403;
      $response['validity'] = false;
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }



  public function forgot_password_post(){
    $response = array();
    if(isset($_POST['email']) && !empty($_POST['email'])){
      $email = $this->input->post('email');
      $query = $this->db->get_where('users', array('email' => $email, 'status' => 1));
      if ($query->num_rows() > 0) {
          $this->api_instructor_model->forgot_password_post();
      }
      // M-03 fix: Always return success to prevent account enumeration
      $response['message'] = 'If this email is registered, you will receive a verification link.';
      $response['status'] = 200;
      $response['validity'] = true;
    }else{
      $response['message'] = 'Email required';
      $response['status'] = 400;
      $response['validity'] = false;
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }


  public function change_profile_photo_post(){
    $response = array();
    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $user_info = json_decode($this->token_data_get($_POST['auth_token']), true);
        $response = $this->api_instructor_model->change_profile_photo_post($user_info['user_id']);
      }else{
        $response['message'] = 'Access denied';
      $response['status'] = 403;
      $response['validity'] = false;
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function userdata_get(){
    $userdata = array();    
      if (isset($_GET['auth_token']) && !empty($_GET['auth_token'])) {
        $auth_token = $_GET['auth_token'];
        $user_info = json_decode($this->token_data_get($auth_token), true);
        $response = $this->api_instructor_model->userdata_get($user_info['user_id']);
      }else{
        $response['message'] = 'Access denied';
        $response['status'] = 403;
        $response['validity'] = false;
      }
      return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_userdata_post(){
    $response = array();
      if (isset($_POST['auth_token']) && !empty($_POST['auth_token'])) {
      $user_info = json_decode($this->token_data_get($_POST['auth_token']), true);
      $response = $this->api_instructor_model->update_userdata_post($user_info['user_id']);
      }else{
      $response['message'] = 'Access denied';
      $response['status'] = 403;
      $response['validity'] = false;
      }
      return $this->set_response($response, REST_Controller::HTTP_OK);
  }


  public function courses_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->courses_get($user_details['user_id']);
      return $this->set_response($response, REST_Controller::HTTP_OK);
    }
  }


  public function add_course_form_get() {
    $response = array();
    $response = $this->api_instructor_model->add_course_form_get();
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }
  
  public function add_course_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->add_course_post($user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

   public function edit_course_form_get() {
     $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['course_id']) && !empty($_GET['course_id'])){
      $course_id = $_GET['course_id'];
      $auth_token = $_GET['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->edit_course_form_get($course_id, $user_details['user_id']);
    }
      return $this->set_response($response, REST_Controller::HTTP_OK);
  }
  
  public function update_course_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_course_post($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_course_status_get(){
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $status = $_GET['status'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_course_status_get($course_id, $status, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function edit_course_requirements_get(){
    $response = array();
    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->edit_course_requirements_get($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_course_requirements_post(){
    $response = array();
    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_course_requirements_post($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function edit_course_outcomes_get(){
    $response = array();
    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->edit_course_outcomes_get($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_course_outcomes_post(){
    $response = array();
    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_course_outcomes_post($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function delete_course_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->delete_course_get($course_id, $user_details['user_id']);
    }

    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function section_and_lesson_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['course_id']) && !empty($_GET['course_id'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->section_and_lesson_get($course_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function sections_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['course_id']) && !empty($_GET['course_id'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->sections_get($course_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function add_section_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token']) && isset($_POST['course_id']) && !empty($_POST['course_id'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->add_section_post($course_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_section_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token']) && isset($_POST['section_id']) && !empty($_POST['section_id'])){
      $auth_token = $_POST['auth_token'];
      $section_id = $_POST['section_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_section_post($section_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function delete_section_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token']) && isset($_POST['section_id']) && !empty($_POST['section_id']) && isset($_POST['course_id']) && !empty($_POST['course_id'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $section_id = $_POST['section_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->delete_section_post($section_id, $course_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }


  public function add_lesson_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token']) && isset($_POST['course_id']) && !empty($_POST['course_id']) && isset($_POST['section_id']) && !empty($_POST['section_id'])){
      $auth_token = $_POST['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->add_lesson_post($user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function lesson_all_data_get(){
    $response = array();

    // H-02 fix: authenticate (token_data_get also enforces the instructor role, M-02)
    // and pass user_id so the model's ownership check runs. Without this the endpoint
    // was called with no user_id — the model already refused (401), but a valid
    // instructor could never use it either. This restores auth + ownership properly.
    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
      $user_id = isset($user_details['user_id']) ? $user_details['user_id'] : 0;
      if(isset($_GET['lesson_id']) && !empty($_GET['lesson_id'])){
        $response = $this->api_instructor_model->lesson_all_data_get($_GET['lesson_id'], $user_id);
      }
    }else{
      $response['message'] = 'Access denied';
      $response['status'] = 403;
      $response['validity'] = false;
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_lesson_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token']) && isset($_POST['lesson_id']) && !empty($_POST['lesson_id'])){
      $auth_token = $_POST['auth_token'];
      $lesson_id = $_POST['lesson_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_lesson_post($lesson_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function delete_lesson_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['lesson_id']) && !empty($_GET['lesson_id'])){
      $auth_token = $_GET['auth_token'];
      $lesson_id = $_GET['lesson_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->delete_lesson_get($lesson_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function sort_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $type = $_POST['type'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->sort_post($user_details['user_id'], $type);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }



  public function course_pricing_form_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $course_id = $_GET['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->course_pricing_form_get($user_details['user_id'], $course_id);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function update_course_price_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $course_id = $_POST['course_id'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->update_course_price_post($user_details['user_id'], $course_id);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function sales_report_get(){
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
    $auth_token = $_GET['auth_token'];
    $user_details = json_decode($this->token_data_get($auth_token), true);
    $response = $this->api_instructor_model->sales_report_get($user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function details_of_sales_report_get(){
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token']) && isset($_GET['payment_id']) && !empty($_GET['payment_id'])){
    $user_details = json_decode($this->token_data_get($_GET['auth_token']), true);
    $payment_id = $_GET['payment_id'];
    $response = $this->api_instructor_model->details_of_sales_report_get($payment_id, $user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function payout_report_get(){
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->payout_report_get($user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);
  }

  public function add_withdrawal_request_post() {
    $response = array();
    
    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->add_withdrawal_request_post($user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);

  }

  public function delete_withdrawal_request_get() {
    $response = array();
    
    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->delete_withdrawal_request_get($user_details['user_id']);
    }
    return $this->set_response($response, REST_Controller::HTTP_OK);

  }


  public function live_class_get() {
    $response = array();

    if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
      $auth_token = $_GET['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->live_class_get($user_details['user_id'], $_GET['course_id']);
      return $this->set_response($response, REST_Controller::HTTP_OK);
    }
  }

  public function save_live_class_data_post() {
    $response = array();

    if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
      $auth_token = $_POST['auth_token'];
      $user_details = json_decode($this->token_data_get($auth_token), true);
      $response = $this->api_instructor_model->save_live_class_data_post($user_details['user_id']);
      return $this->set_response($response, REST_Controller::HTTP_OK);
    }
  }

    function addon_status_get(){
        if(addon_status($_GET['unique_identifier'])){
            $response['status'] = true;
        }else{
            $response['status'] = false;
        }

        $this->set_response($response, REST_Controller::HTTP_OK);
    }
    
    function live_class_settings_get(){
      $response = array();

      if(isset($_GET['auth_token']) && !empty($_GET['auth_token'])){
        $auth_token = $_GET['auth_token'];
        $user_details = json_decode($this->token_data_get($auth_token), true);
        $response = $this->api_instructor_model->live_class_settings($user_details['user_id'], 'get');
        return $this->set_response($response, REST_Controller::HTTP_OK);
      }
    }

    function live_class_settings_post(){
      $response = array();

      if(isset($_POST['auth_token']) && !empty($_POST['auth_token'])){
        $auth_token = $_POST['auth_token'];
        $user_details = json_decode($this->token_data_get($auth_token), true);
        $response = $this->api_instructor_model->live_class_settings($user_details['user_id'], 'post');
        return $this->set_response($response, REST_Controller::HTTP_OK);
      }
    }





}