<?php
/**
 * img.php — social-preview image proxy.
 *
 * Uploaded images are inconsistent: some blog banners are JPEGs saved with a
 * .png name, and course thumbnails are WebP. Strict link-preview crawlers
 * (notably WhatsApp) reject a JPEG served as image/png, and don't support WebP
 * at all. This re-encodes any whitelisted uploads image to a clean JPEG with the
 * correct Content-Type, so previews render everywhere (WhatsApp, Telegram, FB…).
 *
 * Usage:  /img.php?src=uploads/blog/banner/<file>
 */

$src = isset($_GET['src']) ? (string) $_GET['src'] : '';

// Whitelist: uploads/<safe path>.<image ext>, no traversal.
if (!preg_match('#^uploads/[A-Za-z0-9._/\-]+\.(png|jpe?g|webp|gif)$#', $src) || strpos($src, '..') !== false) {
    http_response_code(404);
    exit;
}

// Uploads live under the CodeIgniter app dir (api/uploads/...).
$file = __DIR__ . '/api/' . $src;
$real = realpath($file);
$base = realpath(__DIR__ . '/api/uploads');
if ($real === false || $base === false || strpos($real, $base) !== 0 || !is_file($real)) {
    http_response_code(404);
    exit;
}

header('Cache-Control: public, max-age=604800'); // 7 days

// Preferred path: re-encode to JPEG (handles WebP/PNG/JPEG/GIF uniformly).
if (function_exists('imagecreatefromstring')) {
    $data = @file_get_contents($real);
    $im = ($data !== false) ? @imagecreatefromstring($data) : false;
    if ($im !== false) {
        $w = imagesx($im);
        $h = imagesy($im);
        // Flatten any transparency onto white (JPEG has no alpha channel).
        $canvas = imagecreatetruecolor($w, $h);
        $white = imagecolorallocate($canvas, 255, 255, 255);
        imagefilledrectangle($canvas, 0, 0, $w, $h, $white);
        imagecopy($canvas, $im, 0, 0, 0, 0, $w, $h);
        header('Content-Type: image/jpeg');
        imagejpeg($canvas, null, 85);
        imagedestroy($im);
        imagedestroy($canvas);
        exit;
    }
}

// Fallback: stream the raw bytes with a content-detected type.
$info = @getimagesize($real);
$mime = ($info && !empty($info['mime'])) ? $info['mime'] : 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($real));
readfile($real);
